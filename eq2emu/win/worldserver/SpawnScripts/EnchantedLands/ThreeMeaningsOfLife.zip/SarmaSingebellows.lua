--[[
	Script Name	: SpawnScripts/EnchantedLands/SarmaSingebellows.lua
	Script Purpose	: Sarma Singebellows 
	Script Author	: Cynnar
	Script Date	: 2015.02.24
	Script Notes	: Auto-Generated Conversation from PacketParser Data
--]]

local ThreeMeaningsOfLife = 115

function spawn(NPC)
	SetPlayerProximityFunction(NPC, 10, "InRange", "LeaveRange")
end

function respawn(NPC)
	spawn(NPC)
end

function InRange(NPC, Spawn)
	PlayFlavor(NPC, "voiceover/english/sarma_singebellows/enchanted/halflings/halfling_sarma_singebellows_aoi_callout_unfamiliar_c1948f9b.mp3", "Hey you, c'mere for a sec.", "", 1781622145, 522858713, Spawn)
end

function LeaveRange(NPC, Spawn)
end

function hailed(NPC, Spawn)
	FaceTarget(NPC, Spawn)
	conversation = CreateConversation()

	if HasQuest(Spawn, ThreeMeaningsOfLife) and GetQuestStep(Spawn, ThreeMeaningsOfLife) == 5 then
		SetStepComplete(Spawn, ThreeMeaningsOfLife, 5)
		PlayFlavor(NPC, "voiceover/english/sarma_singebellows/enchanted/sarma_singebellows001.mp3", "", "", 2567471842, 71486470, Spawn)
		AddConversationOption(conversation, "Sure, I'll help you.", "dlg_0_1")
		AddConversationOption(conversation, "I'm not interested in helping.")
		StartConversation(conversation, NPC, Spawn, "See the water here?  The surrounding land tries to filter as much of the evil as it can out of its lifesblood, yet we hang by a thread day by day.  The goblins around here aren't helping, with the grime and muck they pour into the lakes and rivers.  Do you think you could put a stop to them?")
	else
		PlayFlavor(NPC, "voiceover/english/sarma_singebellows/enchanted/halflings/halfling_sarma_singebellows_aoi_callout_unfamiliar_c1948f9b.mp3", "Hey you, c'mere for a sec.", "", 1781622145, 522858713, Spawn)
		AddConversationOption(conversation, "I'm not interested in helping.")
		StartConversation(conversation, NPC, Spawn, "See the water here?  The surrounding land tries to filter as much of the evil as it can out of its lifesblood, yet we hang by a thread day by day.  The goblins around here aren't helping, with the grime and muck they pour into the lakes and rivers.  Do you think you could put a stop to them?")

	end

	--[[	PlayFlavor(NPC, "voiceover/english/sarma_singebellows/enchanted/sarma_singebellows004.mp3", "", "", 2096368456, 1273908771, Spawn)
		AddConversationOption(conversation, "Sure, I'll help you again", "dlg_0_1")
		AddConversationOption(conversation, "Not right now.")
	StartConversation(conversation, NPC, Spawn, "Thank you for your help!  Please take this in return for your hard work.  Do you think you can help me some more?")
	if convo==46 then
		PlayFlavor(NPC, "voiceover/english/sarma_singebellows/enchanted/sarma_singebellows001.mp3", "", "", 2567471842, 71486470, Spawn)
		AddConversationOption(conversation, "Sure, I'll help you.", "dlg_46_1")
		AddConversationOption(conversation, "I'm not interested in helping.")
		StartConversation(conversation, NPC, Spawn, "See the water here?  The surrounding land tries to filter as much of the evil as it can out of its lifesblood, yet we hang by a thread day by day.  The goblins around here aren't helping, with the grime and muck they pour into the lakes and rivers.  Do you think you could put a stop to them?")
	end

	if convo==48 then
		PlayFlavor(NPC, "voiceover/english/sarma_singebellows/enchanted/sarma_singebellows003.mp3", "", "", 2781954391, 3596902388, Spawn)
		AddConversationOption(conversation, "Okay.", "dlg_48_1")
		StartConversation(conversation, NPC, Spawn, "I'm happy to see you're doing well, but I need you to destroy more goblins!")
	end
]]--
end

function dlg_0_1(NPC, Spawn)
	FaceTarget(NPC, Spawn)
	conversation = CreateConversation()

	PlayFlavor(NPC, "voiceover/english/sarma_singebellows/enchanted/sarma_singebellows002.mp3", "", "", 2943069626, 2445316031, Spawn)
	AddConversationOption(conversation, "As you wish.")
	StartConversation(conversation, NPC, Spawn, "Excellent! Goblins are tainting the water and withering the trees at a watermill by a nearby lake.  I want you to destroy as many of them as you can!")
end

--[[ raw_conversations
	PlayFlavor(NPC, "voiceover/english/sarma_singebellows/enchanted/halflings/halfling_sarma_singebellows_aoi_callout_unfamiliar_c1948f9b.mp3", "Hey you, c'mere for a sec.", "", 1781622145, 522858713, Spawn)
	PlayFlavor(NPC, "voiceover/english/sarma_singebellows/enchanted/halflings/halfling_sarma_singebellows_aoi_callout_familiar_2888fa3f.mp3", "Hi, friend!  Are you interested in helping me again?", "", 4027326251, 2342769721, Spawn)
--]]

